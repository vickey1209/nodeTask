const mongoose = require('mongoose');
const jwt = require("jsonwebtoken")
const bcrypt = require("bcryptjs")
require('dotenv').config()

const jwtSecretKey = process.env.JWT_SECRET_KEY

const userSchema = new mongoose.Schema({
        name: {
          type: String,
          required: [true , "name is required"],
          minlength: 5,
          maxlength: 50
        },
        email: {
          type: String,
          required: [true , "email is required"],
          minlength: 5,
          maxlength: 255,
          unique: true
        },
        password: {
          type: String,
          required: [true , "password is required"],
          minlength: 5,
          maxlength: 1024
        },
        confirmpassword: {
            type: String,
            // required: [true , "confirmpassword is required"],
            minlength: 5,
            maxlength: 1024
          }, createdAt: {
            type: Date,
            default: Date.now
          },
        tokens: [{
            token:{
                type: String,
              required : true}
          
        }],
   
        
      });

      //generating tokens

      userSchema.methods.generateAuthToken = async function() {
        try {
            let jwtSecretKey = process.env.JWT_SECRET_KEY;
            // console.log(jwtSecretKey);
          const token = jwt.sign({ _id: this._id.toString() }, jwtSecretKey, {
            expiresIn:"5 second"
                });
          this.tokens.push({ token });
          await this.save();
          console.log(token);
          return token;
        } catch (error) {
          console.log("Error: " + error);
          throw error;
        }
      };

       //hashing password
       userSchema.pre("save" , async function(next)
       {
        if(this.isModified("password")){
       
        console.log(`current password ${this.password}`);
        this.password = await bcrypt.hash(this.password, 10 );
        console.log(`current password ${this.password}`);
        this.confirmpassword = undefined;    // to remove confirmpassword field from database
        }
           next();
       })


    const User = new mongoose.model('User', userSchema);
    module.exports = User;
    // exports.validate = validateUser;
    