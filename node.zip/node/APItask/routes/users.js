const User = require('../model/user');
require('dotenv').config()
const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const bcrypt =require("bcryptjs")

 

          
    // token generation

//     let jwtSecretKey = process.env.JWT_SECRET_KEY;
//     const createToken = async()=>{
//     const token = await jwt.sign({_id:"03135435134354545"}, jwtSecretKey,
//     {
// expiresIn:"5 second"
//     })
//     console.log(token)

//     const userverify = await jwt.verify(token,jwtSecretKey)
//     console.log(userverify)
// }

// createToken()


        //user registration

router.post('/signin', async (req, res) => {
   try{
          
          const password = req.body.password ;
          const cpassword =req.body.confirmpassword;

         if(password === cpassword){
            const registeruser = new User({
                name: req.body.name,
                email: req.body.email,
                password: password,
                confirmpassword:cpassword
             
            });
        
    
        console.log("the success user " + registeruser)
        const token = await registeruser.generateAuthToken();
        console.log("the token part " + token);

        // const password = await registeruser.setPassword();

        const registered =  await registeruser.save();
        res.status(201)
        // console.log("the pagepart" + registered)
    
        }else{
            res.send("password not matching")
        }
    } catch(error)
    {res.status(400).send(error)
    console.log("the error page" , error )}
})
       


router.post('/login',async(req,res)=>{
    try{
    // const {email,password}=req.body;
    const email = req.body.email;
    const password = req.body.password;

    const useremail = await User.findOne({email:email});
    
    //hash password compare
    const isMatch = await bcrypt.compare(password,useremail.password)
 
   if(isMatch)
   {
    res.status(201).json({ message: 'Login successful', useremail });
   }
   else{
    res.status(400).send("invalid login credentials")
   }
        const token = await useremail.generateAuthToken();
        // console.log("the token part " + token);
    // res.send(useremail);
    console.log("login successsfully " + useremail);
    
}
catch(error)
{
    res.status(400).send("invalid email")
}
})

router.get("/display" , async (req , res) => {
    try{  
    
     const users = await User.find();
 
      res.status(201).json(users)
      console.log("displaying all registered users"  , users)
 }
 catch (error)
 {
     console.log('error',error);
     res.status(500).json({error : "server error"});
 }
 })


 router.put('/edit/:_id', async (req, res) => {
    try{
        const _id = req.params.id;
        const update = req.body;
        const result =await User.findByIdAndUpdate(_id , update);
        User.find({}, function(err, result){
            if (err)
            {    
                console.log(err)

            }else
            {
                res.status(201).json({
                              message: 'Thing updated successfully!'
                            })
                          console.log("updated data" , thing);
                    
            }
        })

 }catch(error)
        {
res.send (error)
        }
        })
    


 




router.delete('/delete/:id', function(req, res, next) {
    const userId = req.params.id;
    

    User.findByIdAndDelete(userId).exec()
        .then(doc => {
            if (doc) {
                console.log("user deleted successfully : - " , userId)
                res.status(201).json({ message: 'User deleted successfully' });
            } else {
                res.status(404).json({ message: 'User not found' });
            }
        })
        .catch(err => {
            console.error('Failed to delete user:', err);
            res.status(500).json({ message: 'Error deleting user' });
        });
});


module.exports = router;
 
