
//==============//classes

// class userprofile{
//     constructor(firstname,lastname){
//         this.first = firstname;
//         this.last = lastname;

//     }
//     getname()
//     {
//         console.log(`my firstname is ${this.first} ${this.last} `);
//     }
// }
//     let obj = new userprofile("hello","vickey")
    
//         obj.getname();
    

//==============//promises

// let promise = new Promise((resolve, reject) => {
//     if(true)
//     {
//         resolve("success")
//     }
//     else{
//         reject("reject");
//     }
//     }).then((result)=>{
//         console.log(result);
//     }).catch((error )=>{
//         console.log("error ", error);
//     });

//==============//let & const keyword 

// let sample = "vickey"
// console.log(sample);  

// const sample1 = "lokesh"
// console.log(sample1);

// var sample2 = "rajan"
// console.log(sample2);

//==============// Arrow function
   
//    let add = (a,b)=>
//     a*b;
    
//     console.log(add(2,6));

//     //or

//     const add2 = (c,d)=>{
//        return c+d;
//     }
//     console.log(add2(9,7));

  //multiline log with using back tick

// let greetings = `fsdgghdhdfddg,gsdrgdrgrgg
//   sdrgrfgdrgsg,gdr
// grfgrgrfgdr
// g.edrgde
// rg.edr
// g.e
// rg.e
// rg.
// rg.`
 
// console.log(greetings);

// // deffault parameter 

// //ES6
// let calculateArea = function(height = 100, width = 50) {  

// }


//ES5
// var calculateArea = function(height, width) {  
//    height =  height || 50;
//    width = width || 80;
   
// }

//========================//destructing asignment

// =========//Array Destructuring
// let fruits = ["Apple", "Banana"];
// let [a, b] = fruits; 
// console.log(a, b);

// //Object Destructuring
// let person = {name: "Peter", age: 28};
// let {name, age} = person; 
// console.log(name, age);


// export var num = 50; 
// export function getName(fullName) {   
//    //data
// };

//=========//spread operator

// function number (a,b,c,d)
// {
//   console.log(a+b+c+d);
// }

// const sample = [2,6,47,7,8,]
// number(...sample)

//=======//replace concatination using spread operator

// let sam1 = [2,6,4,7,]
// let sam2 = [3,6,2,4,2,6,5,4,5,"bhfg"]

// let sam3 = sam1.concat (sam1)
// let sam4 = [...sam1,...sam2]

// console.log(sam3);
// console.log(sam4);

//==========//math obj in ES6

// let number = -55.6
// let number2 = 55
// let number3 = 0

// console.log(`sign number : ${Math.sign(number)}`);
// console.log(`sign number : ${Math.sign(number2)}`);
// console.log(`sign number : ${Math.sign(number3)}`);
// console.log(`trunc number : ${Math.trunc(number)}`);
// console.log(`floor number : ${Math.floor(number)}`);
// console.log(`ceil number : ${Math.ceil(number)}`);
// console.log(`abs number : ${Math.abs(number)}`);
// console.log(`round number : ${Math.round(number)}`);
// console.log(`min number : ${Math.min(number)}`);
// console.log(`max number : ${Math.max(number)}`);
// console.log(`max number : ${Math.random(number)}`);

//===========//destructuring assignment 
// destructuring an array 
// let myName, myRole;
// let array = ['vickey', 'Software'];
//  [myName, myRole] = array; //positional assignment occurs here
// console.log(myName, myRole); //John Software Developer

//an object


let myName = "hddd", myRole = "fds";
let array = [ `${myName}, ${myRole}`];
[myName='John', myRole='Software Developer'] = array;
console.log(myName, myRole);

console.log(myRole);