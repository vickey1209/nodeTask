const express = require("express")
const app = express();
const path = require("path")
const User = require("./src/models/user")
const bodyParser = require("body-parser")
const registerroute = require("./src/routes/student")
const connectdb =require("./src/db/conn.js")
const port = 3000;


app.set("view engine","ejs");
// app.set ("views","views");
app.use(express.static(path.join(__dirname , "/views")));
app.use (bodyParser.urlencoded({extended:false}))
app.use(express.static("public"));
app.use(express.json());

app.use("/student" , registerroute)







app.listen (port,()=>{
    console.log(`server running at ${port}`);
})