const mongoose = require("mongoose");

mongoose.connect('mongodb://localhost/aggregation_testing')
    .then(() => 
    console.log('Now connected to MongoDB!')
    )
    .catch(err => console.error('Something went wrong', err));

