const mongoose = require('mongoose');

const db = require("../db/conn")



const studentSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, "name is required"],
    minlength: 1,
    maxlength: 50
  },
  classes: {
    type: String,
    required: [true, "class is required"],
    minlength: 1,
    maxlength: 255,

  },
  subjects: {
    type: String,
    required: [true, "password is required"],
    minlength: 1,
    maxlength: 1024
  },
  school: {
    type: String,
    required: [true, "confirmpassword is required"],
    minlength: 1,
    maxlength: 1024
  },
  city: {
    type: String,
    required: [true, "confirmpassword is required"],
    minlength: 1,
    maxlength: 1024
  },
  createdAt: {
    type: Date,
    default: Date.now
  }


});






const User = new mongoose.model('Student', studentSchema);



async function fetchStudents() {
  try {
    const students = await User.aggregate
      ([{
        $addFields:
          { "lastname": "$name" }
      },
      {
        $sort:
          { "name": 1 }
      },
      { $limit: 10 },
      {
        $project:
          { "name": 1, "classes": 1, "lastname": 1 }
      }
      ])
    // const students = await User.aggregate([{$group:{"_id":"$name" }}])
    console.log(students);
    
  }
 catch (error) {
    console.error(error);
  }
}

fetchStudents()

User.createIndex( { name : -1 }, function(err, result) {
  console.log(result);
  callback(result);
})


db.User.getIndexes()

module.exports = User;

