const express = require("express");
const app = express();

const bodyParser = require("body-parser");
const User = require("../models/user");


const path = require("path");
const { log } = require("console");
const router = express.Router();

app.set("view engine", "pug");
app.set("views", "views");

// bodyparser
app.use(bodyParser.urlencoded({ extended: false }));
;



router.get("/", (req, res, next) => {
  res.render("register");
});

router.post("/", async (req, res, next) => {
  const {
    name,
    classes,
    subjects,
    school,
    city,
 
  } = req.body;

  

  const existingUser = await User.findOne({ name: name });
  if (existingUser) {
    return res.send({ status: "failed", message: "student already exists" });
  }

  if (name && classes && subjects && school && city) {

      try {


        const user = new User({
          name: name,
          classes: classes,
          subjects: subjects,
          school: school,
          city: city 
        });

        await user.save()
        .then((user)=>{
          console.log("User registered:", user);

      
          return res.send("user registered")
          

        })
  
    
      } catch (error) {
        console.log(error);
        return res.send({ status: "failed", message: "Unable to register" });
      }
    
  } else {
    return res.send({ status: "failed", message: "All fields are required" });
  }
});

module.exports = router;






