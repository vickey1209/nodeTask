// SIMPLE QUEUE
import Bull from "bull";
import dotenv from "dotenv";

dotenv.config();
const { REDIS_HOST, REDIS_PORT, REDIS_PASSWORD } = process.env;
const redisOptions = {
  redis: { host: REDIS_HOST, port: REDIS_PORT, password: REDIS_PASSWORD },
};

// DEFINE QUEUE
const burgerQueue = new Bull("burger", redisOptions);

// REGISTER PROCESSER
burgerQueue.process((payload, done) => {
  console.log("Preparing the burger!");
  setTimeout(() => {
    console.log("Burger ready!");
    done();
  },5000);
});




//ADD JOB TO THE QUEUE
burgerQueue.add({
  bun: "🍔",
  cheese: "🧀",
  toppings: ["🍅", "🫒", "🥒", "🌶️"],
})
  .then((job) => {
    console.log(`Job ${job.id} added to the queue`);
  })
  .catch((err) => {
    console.error('Error adding job to the queue:', err);
  });