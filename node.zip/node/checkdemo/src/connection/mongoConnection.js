const mongoose = require ('mongoose');
// import logger from '../logger';

const mongoConnection = async () => {  
mongoose.connect('mongodb://127.0.0.1:27017/checkersgame')
.then(() => {
    logger.info("database connected ...!!");
})
.catch((error) => {
    logger.info('error----', error);
})
mongoose.set('debug', true)

}
module.exports = mongoConnection;