const subConnection = () => {
    const redis = require('redis');
    const subscriber = redis.createClient({
        socket: {
            host: '127.0.0.1',
            port: '6379'
        },
        AUTH: '',
        database: 7
    });
    // client.connect();
    // const subscriber = redis.createClient("redis://127.0.0.1:6379");

    createClientserver = async () => {
        await subscriber.connect();
        console.log("Sub is Connected... !!");
    }
    createClientserver()


    
    subscriber.subscribe('product', (data) => {
        console.log("data===6^^^====subscribe---^^^^--- ",data);
        data = JSON.parse(data);
        io.to(data.roomId).emit("response", data.data)
    });
}

module.exports = subConnection;