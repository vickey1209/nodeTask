const handleRoomEmit = (roomId, data) => {
    console.log("DATA------>", data, "ROOMID------>", roomId);
    publisher.publish("product", JSON.stringify({ roomId, data }))
}
module.exports = handleRoomEmit