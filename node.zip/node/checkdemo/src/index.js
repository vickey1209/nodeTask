const express = require('express');
const app = express();
const server = require("http").createServer(app);
const io = require("socket.io")(server)
app.use(express.static(__dirname + '/views'));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '/views/index.html'))
});
const mongoConnection = require('./connection/mongoConnection');
const pubConnection = require('./connection/pubConnection');
const subConnection = require('./connection/subConnection');
const eventHandler = require('./eventHandler');

mongoConnection();
pubConnection();
subConnection();

io.on('connection', (socket) => {
    global.io = io;

    socket.on('request', async (data) => {
        console.log("data:::::::::",data);
        eventHandler(data, socket)
    });
    console.log("New connection----->", socket.id);
})

const PORT = 4000;
server.listen(PORT, () => {
    console.log("app running at port ::", PORT);
})



