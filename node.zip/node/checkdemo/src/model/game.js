const mongoose = require('mongoose');

const gameSchema = new mongoose.Schema({
    playerInfo: {
        type: Array,
    },
    board: {
        type: Array,
    },
    maxPlayerLength: {
        type: Number,
    },
    activePlayerLength: {
        type: Number
    }
});

const games = mongoose.model("games", gameSchema);
module.exports = games;