

const { handleRoomEmit } = require("../eventEmitter");
const games = require("../model/game");
const players = require("../model/player");



const autoMove = async (data,socket) => {
    // console.log("data_automove-______________", data);
    handleRoomEmit(data.roomtableID.toString(), {
        eventName: "GAME_UPDATES11",
        data: data,
    })
}

module.exports = autoMove;