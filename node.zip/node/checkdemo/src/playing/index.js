const updateGameData = require ('./updateGame');
const autoMove = require ('./autoMove');
const startGame = require ('./startGame');


module.exports = {updateGameData,autoMove,startGame}