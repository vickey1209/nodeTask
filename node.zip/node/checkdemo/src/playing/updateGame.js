const { handleRoomEmit } = require("../eventEmitter");
const games = require("../model/game");
const players = require("../model/player");
// import logger from "../logger";

const updateGameData = async (data,socket) => {
    // console.log("updateGameData________________-",data);
    if (data.roomtableID) {
        await games.updateOne(
            { _id: data.roomtableID },
            { board: data.board },
        );
        var game = await games.findById(data.roomtableID)
        logger.info("game.playGame_________",game);
        // handleRoomEmit(data.roomtableID.toString(), {
        //     eventName:String,
        //     game
        // })
    }
    return;
}

module.exports = updateGameData;