const mongoose = require('mongoose');

const mongoConnection = async () => {  
mongoose.connect('mongodb://127.0.0.1:27017/checkers').then(() => {
    console.log("mongodb connected");
}).catch((error) => {
    console.log('error----', error);
})
mongoose.set('debug', true)

}
module.exports = mongoConnection;