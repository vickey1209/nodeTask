const pubConnection = () => {
    const redis = require("redis")
    const publisher = redis.createClient({
        socket: {
            host: '127.0.0.1',
            port: '6379'
        },
        AUTH: '',
        database: 7
    });
    // const publisher = redis.createClient("redis://127.0.0.1:6379")

    const createClientserver = async () => {
        await publisher.connect()
        global.publisher = publisher
        console.log("Pub Connected");
    }
    createClientserver();
}
module.exports = pubConnection;