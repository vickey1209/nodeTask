const { startGame, autoMove, updateGameData } = require("./game/playGame");

const eventHandler = (data, socket) => {
    // console.log("player data:-", data);
    switch (data.eventName) {
        case "START_GAME":
            startGame(data.data, socket)
            break;
        case "GAME_UPDATES11":
            autoMove(data.data, socket)
            break;
        case "GAME_UPDATES":
            updateGameData(data.data, socket)
            break;
        default:
            break;
    }
}

module.exports = eventHandler;