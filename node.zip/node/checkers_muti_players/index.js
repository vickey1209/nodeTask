const express = require('express');
const app = express();
const server = require("http").createServer(app);
const io = require("socket.io")(server)
app.use(express.static(__dirname + '/views'));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '/views/index.html'))
});
const mongoConnection = require('./connections/mongoDB');
const pubConnection = require('./connections/pub');
const subConnection = require('./connections/sub');
const eventHandler = require('./event');

mongoConnection();
pubConnection();
subConnection();

io.on('connection', (socket) => {
    global.io = io;

    socket.on('request', async (data) => {
        console.log("player data:-",data);
        eventHandler(data, socket)
    });
    console.log("new player socketid created ");
})

const PORT = 4000;
server.listen(PORT, () => {
    console.log(`app is running at port :- ${PORT}`);
})