const { handleRoomEmit } = require("../emitHandler");
const games = require("../model/game");
const players = require("../model/player");



exports.startGame = async (data, socket) => {
    console.log("data============>>>>>>>>", data);

    const Player1 = await players.create({
        playerName: data.playerName,
        socketid: data.socketid,
        turn: data.turn
    })
    console.log("Player1---------", Player1);

    socket.userId = Player1._id.toString();
    let activetable = await games.findOne({ activePlayerLength: { $lt: 2 } })
    // console.log("activetable==========", activetable);
    if (activetable) {
        console.log(" IF ACTIVETABLE------>>");
        await socket.join(activetable._id.toString())
        await players.updateOne(
            { _id: Player1._id },
            { $set: { turn: false, socketid: data.socketid } }
        );

        let Player2update = await players.findOne({ _id: Player1._id })

        await games.updateOne({
            _id: activetable._id
        },
            { $inc: { activePlayerLength: 1 }, $push: { playerInfo: Player2update } })
        activetable = await games.findOne({ _id: activetable._id });

        console.log("last active table", activetable);
        handleRoomEmit(activetable._id.toString(), {
            eventName: "START_GAME",
            data: {
                message: "Players Added...",
                playerInfo: activetable.playerInfo,
                tableId: activetable._id.toString(),
                board: activetable.board
            }
        });
    } else {
        // console.log("ELSE NOT ACTIVETABLE-------->>");
        let tableData = await games.create({
            maxPlayerLength: 2,
            activePlayerLength: 1,
            playerInfo: [Player1],
            board: [
                null,
                0,
                null,
                1,
                null,
                2,
                null,
                3,
                4,
                null,
                5,
                null,
                6,
                null,
                7,
                null,
                null,
                8,
                null,
                9,
                null,
                10,
                null,
                11,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                12,
                null,
                13,
                null,
                14,
                null,
                15,
                null,
                null,
                16,
                null,
                17,
                null,
                18,
                null,
                19,
                20,
                null,
                21,
                null,
                22,
                null,
                23,
                null,
            ]
        });

        // console.log("tableData---------->>>>>", tableData);

        socket.join(tableData._id.toString());
        socket.handshake.auth.tableId = tableData._id;
        const tableId = socket.handshake.auth.tableId;
        // console.log('tableId*********', tableId);

        handleRoomEmit(tableData._id.toString(), {
            eventName: "START_GAME",
            data: {
                message: "Players Added...",
                playerInfo: tableData.playerInfo,
                tableId: tableData._id.toString(),
                board: tableData.board
            }
        })
    }
}

exports.autoMove = async (data, socket) => {
    // console.log("data_automove-______________", data);
    handleRoomEmit(data.roomtableID.toString(), {
        eventName: "GAME_UPDATES11",
        data: data,
    })
}

exports.updateGameData = async (data, socket) => {
    // console.log("updateGameData________________-",data);
    if (data.roomtableID) {
        await games.updateOne(
            { _id: data.roomtableID },
            { board: data.board },
        );
        var game = await games.findById(data.roomtableID)
        console.log("game.playGame_________",game);
        handleRoomEmit(data.roomtableID.toString(), {
            eventName: "GAME_UPDATES",
            game
        })
    }
    return;
}