const mongoose = require('mongoose');



const userSchema = new mongoose.Schema({
        name: {
          type: String,
          required: [true , "name is required"],
          minlength: 5,
          maxlength: 50
        },
        email: {
          type: String,
          required: [true , "email is required"],
          minlength: 5,
          maxlength: 255,
          unique: true
        },
        phone: {
          type: Number,
          required: [true , "number is required"],
          minlength: 5,
          maxlength: 1024
        },
        gender: {
          type: String,
          required: [true , "number is required"],
          minlength: 5,
          maxlength: 1024
        },
        city: {
          type: String,
          required: [true , "number is required"],
          minlength: 5,
          maxlength: 1024
        }, 
        createdAt: {
            type: Date,
            default: Date.now
          }
   
   
        
      });

      


    const User = new mongoose.model('User', userSchema);
    module.exports = User;
   
    