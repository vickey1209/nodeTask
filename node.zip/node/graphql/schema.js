const graphql = require('graphql')

const {GraphQLObjectType,
 GraphQLSchema,
 GraphQLInt, 
 GraphQLString,
 GraphQLList } = graphql;


const db = require("./config/db/conn.js")
const User  = require("./model/user.js")

 const rootquery = new GraphQLObjectType({
    name:"vickey",
    fields:{

    userlist:{
        type: new GraphQLList(userType),
        resolve(parents,args){
            let data = User.find()
        return data
        }
    
     }, 
   }
 })


 module.exports =  new GraphQLSchema({query:rootquery})