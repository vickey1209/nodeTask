const graphql = require('graphql')

const {GraphQLObjectType,
 GraphQLSchema,
 GraphQLInt, 
 GraphQLString,
 GraphQLList } = graphql;

 
const{user_list,user_list2} = require("../schema/queries/query.js")
const{user_add} = require("./mutation/usermutation.js")

 const rootquery = new GraphQLObjectType({
    name:"vickey",
    fields:{

    userlist:user_list,
    vehiclelist:user_list2
    }
 })

 const Mutation = new GraphQLObjectType({
   name:"mutation",  
   fields:{
      createUser:user_add
   }
 })

 module.exports =  new GraphQLSchema({query:rootquery, mutation : Mutation})