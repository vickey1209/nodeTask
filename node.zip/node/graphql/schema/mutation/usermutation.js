var db = require("../../config/db/conn.js")
const User = require("../../model/user.js")
const{GraphQLList, GraphQLInt, 
    GraphQLString} = require('graphql')

const userType = require("../typedef/usertype.js")

module.exports.user_add = {
    type: userType, 
    args:{
        name:{type:GraphQLString},
        email:{type:GraphQLString},
        gender:{type:GraphQLString},
        city:{type:GraphQLString}
    },
    resolve(parent,args){
        db.User.insert({name:args.name,email:args.email , gender:args.gender , city: args.city}) 
    return args
    }

 }