var db = require("../../config/db/conn.js")
const User = require("../../model/user.js")
const{GraphQLList} = require('graphql')

const userType = require("../typedef/usertype.js")

module.exports.user_list = {
    type: new GraphQLList(userType),
    resolve(parent,args){
        let data = User.find({"name":"lala"})
    return data
    }

 }

 module.exports.user_list2 = {
    type: new GraphQLList(userType),
    resolve(parent,args){
        let data = User.find()
    return data
    }

 }