const express = require("express")
const app = express()
const port = 7000;
const {graphqlHTTP} = require("express-graphql");
DATABASE_URL = "mongodb://localhost:27017"
const connectDB = require("./config/db/conn.js")
const User  =require("./model/user.js")

connectDB(DATABASE_URL)

const schema = require('./schema/index.js')

app.use(express.json());

app.use('/graphql',
      graphqlHTTP({
      schema,
      graphiql: true
})
)

app.listen(port,()=>{
    console.log(`server is running at port${port}`);
})
