const express = require("express")
const app = express()
port = 7000;

app.json


app.use("/api/user", userroute)

app.listen(port,()=>{
 console.log(`server is running at port ${port}`);    
})