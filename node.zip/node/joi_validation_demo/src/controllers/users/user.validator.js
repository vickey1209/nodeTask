const joi = require("joi");
const errorfunction = require("../../utils/errorfunction");

const validation = joi.object({
     username: joi.string().alphanum().min(3).max(25).trim(true).required(),
     email: joi.string().email().trim(true).required(),
     password: joi.string().min(8).trim(true).required(),
     mobilenumber: joi.string().length(10).pattern(/[6-9]{1}[0-9]{9}/).required(),
     birthyear: joi.number().integer().min(1920).max(2000),
     skillSet: joi.array().items(joi.string().alphanum().trim(true))
.default([]),
    is_active: joi.boolean().default(true),
});