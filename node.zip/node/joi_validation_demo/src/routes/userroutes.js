const express = require("express");
const defaultController = require("../controllers/defaultController.js");
const userValidation = require("../controllers/users/user.validator.js");
const { addUser, getUsers } = require("../controllers/users/user.controller.js");


router.post("/addUser", userValidation, addUser);


router.get("/getUsers", getUsers);

const router = express.Router();

router.get("/", defaultController);

module.exports = router;