require("dotenv").config();
const express = require("express");
const connectDB = require("../src/db/conn.js")
const DATABASE_URL = process.env.DATABASE_URL


const app = express();
const port = process.env.PORT;

connectDB(DATABASE_URL)


app.use(express.json({ limit: "10MB" }));
app.use(express.urlencoded({ extended: true }));



app.listen(port, () => {
console.log(`Server is running at ${port}`);
});