const express = require("express")
const app = express()
const port = 7000


app.use(express.json());

const Joi = require('joi')

function validateUser(user)
{
	const JoiSchema = Joi.object({
	
		username: Joi.string()
				.min(5)
				.max(30)
				.required(),
					
		email: Joi.string()
			.email()
			.min(5)
			.max(50)
			.optional(),
				
		dateofbirth: Joi.date()
					.optional(),
						
		account_status: Joi.string()
						.valid('activated')
						.valid('unactivated')
						.optional(),
	}).options({ abortEarly: false });

	return JoiSchema.validate(user)
}

const user = {
	username: 'Pritis',
	email: 'pritish@gmail.com',
	dateofbirth: '2020-8-11',
	account_status: 'activated'
}

response = validateUser(user)

if(response.error)
{
	console.log(response.error.details)
}
else
{
	console.log("Validated Data")
}





app.listen(port,()=>{
    console.log(`server is running at ${port}`);
})    