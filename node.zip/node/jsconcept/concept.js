//scope

//LOCAL SCOPE

/*The code given below will give you an error because “name”
 is defined within the boundary (local scope) of the showName() function.
  You can not have access to this variable outside the function.*/
  
// function showName(){
// 	let name = "GCSDSDSFGVD";
//     console.log(name);
// }
// showName()
// // console.log(name);

//BLOCK SCOPE

// function fun() {
//   const a = 10;
// 	console.log(a);
// }
// fun()


// IIFE (Immediately Invoked Function Expression)

// let paintColor = 'red'
// const paint = (() => {
// 	return {
// 		changeColorToBlue: () => {
// 			paintcolor: 'Blue'; return paintColor;
// 		},
// 		changeColorToGreen: () => {
// 			paintColor: 'Green';
// 			return paintColor;
// 		}
// 	}
// })();
// console.log(
// 	paint.changeColorToBlue()
// );

//hoisting

function cowsays(sound)
{
    console.log(sound);
}
cowsays("mooo")