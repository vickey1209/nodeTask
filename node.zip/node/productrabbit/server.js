const app = require("express")()
const amqp = require('amqplib/callback_api')
const http = require("http").Server(app)
port = 3000;


//consumer 
app.get ('/product', (req , res)=>{
    try {
        amqp.connect('amqp://localhost' , function (err , conn){
            conn.createChannel(function(err , ch){
    
                const queue = 'message_queue_user'
                ch.assertQueue(queue,{durable:false})
                
                ch.consume(queue, function(msg){
                
                    console.log('Msg', msg.content.toString());
                    res.send(msg.content.toString())
                }, {noAck:true})
            })
        })
        
        
    } catch (error) {
        console.log(error ,"waiting for the message from queue");
    }  
})
                                                                  
http.listen (port , () =>{
console.log(`products service server running at ${port}`);    
})