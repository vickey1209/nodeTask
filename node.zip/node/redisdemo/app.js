const Redis = require('ioredis');
const redis = new Redis(); // Connect to the local Redis server (default configuration)

// Set a key-value pair
redis.set('myKey', 'Hello, vickey!');

// Retrieve the value
redis.get('myKey', (err, result) => {
  if (err) {
    console.error(err);
 
  } else {
    console.log('Value:', result);
  }

  // Close the Redis connection
  redis.quit();
});
