const express = require('express');
const Redis = require('ioredis');

const app = express();
const redis = new Redis();

const PORT = process.env.PORT || 3000;

app.use(express.json());


app.post('/register', async (req, res) => {
  const { username, email , city } = req.body;

 
  const userExists = await redis.get(username);

  if (userExists) {
    return res.status(400).json({ message: 'Username already exists.' });
  }
  
  
  await redis.set(city, JSON.stringify({ username, email , city}));

  return res.status(201).json({ message: 'User registered successfully.',   });
 
});


app.get('/user/:username', async (req, res) => {
    const { username } = req.params;
  
    // getting data from user
    const userData = await redis.get(username);
  
    if (!userData) {
      return res.status(404).json({ message: 'User not found.' });
    }
  
    const parsedUserData = JSON.parse(userData);
    console.log(parsedUserData);
    return res.status(200).json(parsedUserData);
    
  });



app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
