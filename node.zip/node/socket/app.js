const express = require("express");
const app = express();
const path = require("path");
const http = require("http").createServer(app);
const io = require("socket.io")(http);
port = 3000

app.get('/', (req , res) =>{

  const options = {
  root:path.join(__dirname)
  }
  const filename = "index.html"
    
  res.sendFile(filename , options)

})
 
var users = 0;

io.on("connection", function(socket){
    console.log("a user connected");
    users++;
    socket.emit('newuserconnect',{message: 'hi welcome dear'});
    // console.log("total users", users++ )

    socket.broadcast.emit('newuserconnect',{message: users + "users connected"});
    io.sockets.emit({message: 'everyone is connected'});
    //create event

//     setTimeout(function(){
//     // socket.send('send message from server side ');
//     socket.emit('mycustomevent', {description: 'a custom message from server side'})
// }, 3000);

// socket.on('mycustomeeventfromclientside',function(data){
//     console.log(data);
// })
     
    socket.on("disconnect",function(){
        console.log("user disconnected");

        users--;
        socket.broadcast.emit(' ',{message: users+"users connected"})
    //    io.sockets.emit('broadcast',{message:users + 'users disconnected..!'});
    // console.log("total users", users-- )

    });
});




http.listen(port,() =>
console.log(`server running at ${port}`))


