const express = require ("express")
const app = express()
const http = require("http").createServer(app)
const io = require("socket.io")(http);
const path = require("path")
port = 3600

app.get("/",(req , res)=>{
    res.sendFile(path.join(__dirname, "index.html"));
 
})
var users = 0

io.on("connection" , (socket)=>{
    console.log("user connected")
    users++
    console.log(users);
    //broadcasting
//   io.sockets.emit("broadcast",{message: users + " " + "Users Connected"})  //used for globally
    socket.emit("newuserconnect",{message:"hello , hows you?"})

    socket.broadcast.emit("newuserconnect",{message: users + " " + "Users Connected"})

socket.on("disconnect", function(){
  console.log("user disconnected")
  users--
  console.log(users);
  socket.emit("newuserconnect",{message:"hello , hows you?"})
   

//   io.sockets.emit("broadcast",{message: users + " " + "Users disconnected"})
  })

})




http.listen(port, ()=>{
console.log(`server is runnning at ${port}`)
})