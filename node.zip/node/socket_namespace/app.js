const express = require ("express")
const app = express()
const http = require("http").createServer(app)
const io = require("socket.io")(http);
const path = require("path")
port = 3700

app.get("/",(req , res)=>{
    res.sendFile(path.join(__dirname, "index.html"));
 
})

var cnsp = io.of('/custom-namespace')

cnsp.on("connection" , function(socket){
    console.log("user connected")

    cnsp.emit('customevent',"tester event call");

socket.on("disconnect", function(){
  console.log("user disconnected")
  
  });

});




http.listen(port, ()=>{
console.log(`server is runnning at ${port}`)
})