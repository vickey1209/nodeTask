const express = require("express");
const app = express();
const http = require("http").createServer(app)
const io = require("socket.io")(http);
const path = require("path")
port = 3000

app.get("/",(req , res)=>{
    res.sendFile(path.join(__dirname, "index.html"));
 
})

io.on('connection', (socket)=> {
    console.log("user connected");

    setTimeout(() => {
        socket.send("testing");
    }, 3000);

    setTimeout(() => {
        socket.emit("artoon" , {description:"solutions "});
    }, 5000);
    
    socket.on("disconnect", function() {
      console.log("user disconnected");

      
    });
    socket.on("firstevent", function(data) {
        console.log(data);
  
        
      });

});


http.listen(port, ()=>{
console.log(`app is running at port ${port}`);
})






