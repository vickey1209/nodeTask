// // function Addition(a,b)
// // {
// //    return(a*b)

// const { clear } = require("console");

// const { log } = require("console");


// // }
// // console.log(5,6);

// function name()
// {
//     let a="vickey",
//     b="sourabh",
//     c="nancy"
//     return [a,b,c]
// }
// let [a,b,c]= name();
// console.log(a)
// console.log(b)
// console.log(c)

//===========================================================================================================================
//promise

// const promise = new Promise((resolve, reject) => {
//     if (false) {
//       resolve("Promise resolved");
//     } else {
//       reject("Promise rejected");
//     }
//   }).then((result) => {
//     console.log(result);
//   }).catch((error) => {
//     console.log(error);
//   });
//===========================================================================================================================


// var marks = {rohit:12 , bilo:25}
// var num1 = 53;
// var num2 = 53;
// console.log(num1+num2);

// var a = true;
// var b = false;
// console.log(a,b);


// var d = [2,6,3,5,"hellooovickey",74,8,59,6,100]
// console.log(d[4])

// console.log(num1==num2)
// console.log(num1||num2)
// console.log(num1==num2)
// console.log(num1==num2)
// console.log(num2==num2)
// console.log(num1==num2)

// console.log(!false === !true);

// var a =5
// var b= 10
// var c = b
// console.log(a,b,c)

//===========================================================================================================================



// functions
// function avg(a, b) {
//   c = (a + b) / 2
//   return c
// }

// d = avg(40,20)
// console.log(d)

// age = 17
// if(age>18 && age<60)
// {
// console.log("person can vote");
// }
// else if(age>60)
// {
// console.log("person is senior citizen");
// }

// else {
//   console.log("person died");
// }

//===========================================================================================================================


//for loop
// var arr = [22,23,33,34,35,36,37,38]
// for(var i = 1; i < arr.length; i++)
// {
//   console.log(arr[i])
// }

//===========================================================================================================================


//foreach

// arr.forEach(function(element)
// {
//   console.log(element)
// })


// var arr = [22, 23, 33, 34, 35, 36, 37, 38]
// for (var i = 0; i < arr.length; i++) {
//   if (i == 2) {
//     break;   // it stops at i==2
//     continue    // it continues from 2
//   }
//   console.log(arr[i])
// }

//===========================================================================================================================


// date

// let mydate = new Date();
// {
//   console.log(mydate.getTime());
//   console.log(mydate.getFullYear());
//   console.log(mydate.getDay());
//   console.log(mydate.getMinutes());
//   console.log(mydate.getSeconds());
// }

//===========================================================================================================================


// ARROW FUNCTION
// sum = (a,b)=>{
//   return a+b
// }

//===========================================================================================================================


// settimeout

// setTimeout((login) => {
//   console.log("i m vickey shrivastava");
// }, 5000);

// //setinterval 
// setInterval((login) => {
//   console.log("i m vickey shrivastava");
// }, 5000);

//===========================================================================================================================


// JAVASCRIPT LOCAL STORAGE

//if else question
// function checknumber(number)
// {
//   if (number < 0){
//     console.log("number is negative")
//   }
//   else if(number > 0)
//   {
//     console.log("number is positive");
//   }
//   else {
//     console.log("number is zero");
//   }

// }
// checknumber(0);
// checknumber(-3);
// checknumber(4);

//===========================================================================================================================


// function compare(a,b)
// {
//   if(a>b)
//   {
// console.log(`${a} is greater than ${b}`)
//   }else if (a<b)
//   {
//     console.log(`${a} is less than ${b}`);
//   }
//   else{
//     console.log(`${a} is equal to ${b}`);
//   }
// }
// compare(6,6)

//===========================================================================================================================


//even odd

// function evenodd(number){
//   if(number % 2==0 )
//   {
//     console.log("number is even");
//   }
//   else{
//     console.log("number is odd");
//   }
// }

// evenodd(9);
// evenodd(10);
// evenodd(5);

//===========================================================================================================================

// function diff(a,b)
// {
//   if (a>b)
//   {
//   return a-b
//   }
//   else 
//   {
//     return b-a
//   }
// }
 
// console.log(diff(7,3))
// console.log(diff(2,3))

//===========================================================================================================================


//greatest number

// function greatest (a,b,c,d){
// if(a>=b && a>=c && a >=d)
// {
//   return a
// }
// else if (b>= c && b>= d && b >= a)
// {
//   return b
// }
// else if (c>= d && c>= a && c >= b)
// {
//   return c
// }
// else{
//   return d
// }
// }

// console.log(greatest(2,554,44,6));
//===========================================================================================================================


//reverse string

// function reverse(str)
// {
//   return str.split('').reverse().join('')
// }

// console.log(reverse("vickey"));
// console.log(reverse("gwgrwsrvsgs"));

//===========================================================================================================================


// let user = "hello"
// let player = "fsdfg"
// if(user = player)
// {
//     console.log("gf");
// }
// else{
//     console.log("ffffff");
// }

//===========================================================================================================================


// const student
// ={
//     name:"vickey",
//     roll:25,
//     age:55,
//     city: "bhopal"
// }

// const docu = function(){

// };
// console.log(student);
//===========================================================================================================================


// module.exports = function(options) {
//     options = options || {};
//     var loggingLvl = options.logLevel || 1;

//     function logMessage(logLevel, message) {
//         if(logLevel <= loggingLvl) {
//             console.log(message);
//         }
//     }

//     return {
//         log: logMessage
//     };
// }

//===========================================================================================================================

// try-ccatch block

// try {
    
//  for(let i=0; i<5 ; ++i){
//     console.log("fdg");
//    }    
// } catch (error) {
//     console.log(error);
    
// }

//===========================================================================================================================

// if else conditioon 

// let i = 0;

// if(i>5)
// {
// console.log("helo");
// }
// else {
// console.log("hehe");
// }
//===========================================================================================================================

// for in loop 
//  var x = "wawa"
// let student = "";
// for(let i in x)
// student += x[i] + ""
// console.log(student);

      //  or

// let x = "wawa";
// let student = "";

// for(let i in x) {
//     student += x[i] + "";
// }

// console.log(student);


// let person ={
//      age : 27, name:"vickey", school: "hello" , city : "ahmedabad"
// }

// let human = ''

// for (let persons in person){
//     human += person[persons] + "  "
// }
// console.log(human);

// for in looop
// let company = { name : "infosys" , department :"IT" , city : "bhopal"}
// let employee = ""

// for (let companies in company){
//     employee += company[companies] +" "
// }
// console.log(employee);


//===========================================================================================================================
//reverse array

// const array = [2,5,4,89,7,6,4,8,8,8,8,2]
// const reversearr = (index )=>{
//     if(array[index+1]){
//     reversearr(array[index+1])
//     }
//     console.log(array[index])
// }
// reversearr(0)
//===========================================================================================================================
//reverse array


// const array = [2, 5, 4, 89, 7, 6, 4, 8, 8, 8, 8, 2];

// const reversearr = (index) => {
//   if (index < array.length) {
//     reversearr(index + 1);
//     console.log(array[index]);
//   }
// };

// reversearr(0);


//===========================================================================================================================
//reduce Right

// const number = [175,50,25]


// function myFunc(total , num,i )
// {
//   console.log(i, total, num );
//   return total-num;
// }
// console.log(number.reduceRight(myFunc));

//===========================================================================================================================
//reduce

// const number = [175,50,25,36,55,44,88]


// function myFunc(total , num ,i)
// {
//   console.log(i, total, num );
//   return total-num;
// }
// console.log(number.reduce(myFunc));
//===========================================================================================================================

// Object.assign()

// const target = { a: 1, b: 5 , d:6};
// const source = {a:6, b: 4, c: 5 };

// const returnedTarget = Object.assign(target, source);
// // console.log(source);
// console.log(target);
// // Expected output: Object { a: 1, b: 4, c: 5 }

// console.log(returnedTarget === target);
// // Expected output: true


//===========================================================================================================================
// function fetchDataFromApi() {
//       // Data fetching logic here
//       console.log(data);
//     }
    
//     fetchDataFromApi();
//     console.log('Finished fetching data');

//===========================================================================================================================


async function fetchDataFromApi() {
      try {
        const { default: fetch } = await import('node-fetch');
    
        const response = await fetch('your_api_endpoint');
        const data = await response.json();
        console.log(data);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    }
    
    fetchDataFromApi().then(() => {
      console.log('Finished fetching data');
    });
    