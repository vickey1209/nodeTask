

import mongoose from 'mongoose';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import express from 'express';

const app = express();

// app.get("/", (req:any, res:any)=>{
//     res.send("");
// })`

mongoose.connect('mongodb://localhost/vickey')
    .then(() => 
        console.log('Now connected to MongoDB!')
    )
    .catch(error => console.error('Something went wrong', error));

app.use(express.json());


const port = process.env.PORT || 4000;
app.listen(port, () => console.log(`Listening on port ${port}...`));

 