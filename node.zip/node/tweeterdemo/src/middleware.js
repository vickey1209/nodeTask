// exports.requirelogin = (req , res , next)=>{
//     if(req.session && req.session.user)
//     {
//         return next();
//     }
//     else{
//         res.status(200).render("login")
    
//     }
// }


exports.requirelogin = (req, res, next) => {
    if (req.session.user) {
       //allowed
       return next();
    } else {
       //denied
        res.redirect("/");
    }
};


