"use strict";
const caryear = 2001;
const carmodel = "toyota";
const cartype = "hatchback";
const car = {
    year: caryear,
    type: cartype,
    model: carmodel
};
console.log(car);
