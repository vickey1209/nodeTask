type caryear = number
type carmodel = string
type cartype = string

type car=
{
    year : caryear,
    model: carmodel,
    type: cartype


}

const caryear :number = 2001
const carmodel : string ="toyota"
const cartype : string = "hatchback"
const car  = {
    year:caryear,
    type:cartype,
    model:carmodel
}

console.log(car);


