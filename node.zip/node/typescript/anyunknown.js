"use strict";
//any
let user = 5;
user = "heds";
user = true;
console.log(user);
//OR
function printLength(value) {
    console.log(value.length);
}
let dValue = "GDFFHDFHH";
printLength(dValue);
//unknown
let consumer;
consumer = "heed";
console.log(consumer);
//OR
function safePrintLength(value) {
    if (typeof value === "string") {
        console.log(value.length);
    }
    else {
        console.log("VALUE NOT STRING");
    }
}
let dynamicValue = "HEL!";
safePrintLength(dynamicValue);
