
//any
let user : any = 5
user = "heds"
user= true
console.log(user);

//OR

function printLength(value: any) {
    console.log(value.length); 
  }
  
  let dValue: any = "GDFFHDFHH";
  printLength(dValue); 

//unknown
let consumer : unknown
consumer = "heed"
console.log(consumer);

//OR
 
 function safePrintLength(value: unknown) {
    if (typeof value === "string") {
      console.log(value.length); 
    } else {
      console.log("VALUE NOT STRING");
    }
  }
  
  let dynamicValue: unknown = "HEL!";
  safePrintLength(dynamicValue); 
  
  