//enum 
enum Roles{

    user = "user",
    admin = "admin"

}

type logindetails = {
    name?: string;
    email: string;
    password: string;
    role:Roles;
}

const user1 = {
    name:"vickey",
    email : "dasfse@gmail.com",
    password: "123",
    role: Roles.user
}

const user2 = {
  name: "sanket",
  email:"vsdfvdfg@gmail.com",
  password: "2321",
  role : Roles.admin

}


const isadmin : (user:logindetails) => string = (user:logindetails):string =>{
    const {name,email, role, password} = user;
    return role==="admin" ? `${name} is allowed to edit the website`: `${name} is  not allowed to edit the website`

}

console.log(isadmin(user1));
console.log(isadmin(user2));
