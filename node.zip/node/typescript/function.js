"use strict";
//return type function
function add(a, b) {
    return a * b;
}
let result = add(2, 5);
console.log(result);
//void function = which doesnt returnn anything 
function red() {
    console.log('Hello!');
}
red();
// the `?` operator here marks parameter `c` as optional
function func(a, b, c) {
    return a + b + (c || "hello");
}
console.log(func(2, 5));
