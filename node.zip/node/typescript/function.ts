//return type function

function add(a:number,b:number)
{
  return a*b
}
let result = add(2,5);
console.log(result);


//void function = which doesnt returnn anything 

function red(): void {
    console.log('Hello!');
  }
  
  red();


  // the `?` operator here marks parameter `c` as optional
function func(a: number, b: number, c?: string) {
    return a + b + (c|| "hello")
  }
  
  console.log(func(2,5))