"use strict";
// generics
function logandreturn(value) {
    return value;
}
const numberResult = logandreturn(255);
const stringResult = logandreturn("hello");
console.log(numberResult);
console.log(stringResult);
