// generics

function logandreturn<M>(value:M):M {
    return value;
    
}

const numberResult:number = logandreturn(255);
const stringResult: string= logandreturn("hello");

console.log(numberResult);

console.log(stringResult);
