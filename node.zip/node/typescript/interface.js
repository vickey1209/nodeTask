"use strict";
//interfaces
const rectangle = {
    height: 15,
    weight: 20
};
console.log(rectangle);
const carassemble = {
    wheels: 4,
    color: "white",
    fuels: "petrol",
    seats: 5,
    doors: 4
};
console.log(carassemble);
