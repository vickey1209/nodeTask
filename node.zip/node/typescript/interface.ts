//interfaces

interface rectangle  {
    height: number ,
    weight: number
}

const rectangle: rectangle =  {
 height:15,
 weight:20
}

console.log(rectangle);

//extending interfaces

interface cars {
    color: string,
    wheels: number,
    seats: number 
}

interface carfeatures extends cars{
     doors: number,
     fuels: string 
} 

const carassemble : carfeatures = {
    wheels: 4,
    color: "white",
    fuels : "petrol",
    seats: 5 ,
    doors : 4
};

console.log(carassemble);
