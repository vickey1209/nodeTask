"use strict";
//type initialize
//function to display person information
const displaypersoninfo = (person) => {
    const [name, age, hasdriving_liscence] = person;
    console.log(`name : ${name} , age: ${age}, has driving liscence: ${hasdriving_liscence ? "yes" : "no"} `);
};
//usage
const person1 = ['vickey', 22, true];
const person2 = ["sanket", 26, false];
displaypersoninfo(person1);
displaypersoninfo(person2);
