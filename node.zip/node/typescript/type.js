"use strict";
// var a = 3
// a=2 
// console.log(a);
// Function that greets a person
function greetPerson(person) {
    console.log(`Hello, ${person.firstName} ${person.lastName}! You are ${person.age} years old.`);
}
// Sample person object
const alice = {
    firstName: "Alice",
    lastName: "Johnson",
    age: 30
};
// Calling the function with the person object
greetPerson(alice);
// Calculate the sum of an array of numbers
function sumArray(numbers) {
    return numbers.reduce((total, num) => total + num, 0);
}
//array
const numbersArray = [1, 2, 3, 4, 5];
// Calculate and display the sum
const totalSum = sumArray(numbersArray);
console.log(`Total sum: ${totalSum}`);
let fname = "hello";
fname = "gtgt";
console.log(fname);
function sum(a, b) {
    return a + b;
}
console.log(sum(5, 5));
let string = "helooooooooooooooooooooodasdafo";
console.log("length ", string.length);
