// var a = 3
// a=2 
// console.log(a);

// let age: number = 25; 
// let name: string = "John";
// let isStudent: boolean = true

// let score = 100; 
// let message = "Hello"; 

// let value: any = "42";
// let length: number = (<string>value).length; 

// console.log(score);

// Define a type for a person
type Person = {
    firstName: string;
    lastName: string;
    age: number;
}; 

// Function that greets a person
function greetPerson(person: Person): void {
    console.log(`Hello, ${person.firstName} ${person.lastName}! You are ${person.age} years old.`);
}

// Sample person object
const alice: Person = {
    firstName: "Alice",
    lastName: "Johnson",
    age: 30
};

// Calling the function with the person object
greetPerson(alice);

// Calculate the sum of an array of numbers
function sumArray(numbers: number[]): number {
    return numbers.reduce((total, num) => total + num, 0);
}

//array
const numbersArray: number[] = [1, 2, 3, 4, 5];

// Calculate and display the sum
const totalSum: number = sumArray(numbersArray);
console.log(`Total sum: ${totalSum}`);

let fname:String = "hello"
fname = "gtgt";
console.log(fname);


function  sum(a:number,b:number)
{
  return a+b
}
console.log(sum(5,5));

let string = "helooooooooooooooooooooodasdafo"
console.log("length ",string.length);
