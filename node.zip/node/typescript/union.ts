//  in this union we can take any type (multi types using pipe operators )as datatypes for function

function truck (quantity : string | number | boolean)
{
    console.log(`i have ${quantity} cars `);
    
}
truck(4);
truck ("four");
truck (true)