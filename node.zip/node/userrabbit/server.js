const app = require("express")()
const http = require("http").Server(app)
const amqp = require('amqplib/callback_api');

port = 3001;

// producer 

app.get('/users', (req, res) => {
    let data = {
        id: 3,
        name: "sachin",
        age: 23
    }
    amqp.connect('amqp://localhost', function (err, conn) {
        conn.createChannel(function (err, ch){

            const queue = 'message_queue_user'
            const msg = JSON.stringify(data)
            ch.assertQueue(queue, { durable: false });
            ch.sendToQueue(queue, Buffer.from(msg))
            console.log(`sent ${msg} to ${queue}`)
        })
    })
    res.send( "message from user service ")
})


http.listen(port, () => {
    console.log(`users service server running at ${port}`);
})